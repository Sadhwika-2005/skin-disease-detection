from django.apps import AppConfig


class SkindiseaseappConfig(AppConfig):
    name = 'SkinDiseaseApp'
